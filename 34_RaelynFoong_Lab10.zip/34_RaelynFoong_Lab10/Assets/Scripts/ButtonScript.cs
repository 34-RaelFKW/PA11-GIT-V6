﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ButtonScript : MonoBehaviour
{
    public Text scoreText;
    public float score;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Obstacle"))
        {
            score++;
            scoreText.text = "Score: " + score;
        }
    }
    public void RestartBtn()
    {
        SceneManager.LoadScene(0);
    }
}
